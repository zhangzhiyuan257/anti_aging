from feature_extraction import *
# from normalization import ZScore
import re
import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.model_selection import train_test_split
# from sklearn.metrics import f1_score
# from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
# from machinelearning import *
from sklearn.model_selection import cross_val_score
from sklearn.metrics import RocCurveDisplay
from sklearn.metrics import auc,roc_curve
import matplotlib.pyplot as plt
import math


def mls(data_pd, b, n=1):
    X,y = data_pd.iloc[n:, 2:],data_pd.iloc[n:, 1].astype("int")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=10)
    print(X_test)
    cv = StratifiedKFold(n_splits=10)
    clf = RandomForestClassifier(n_estimators=100, random_state=0)
    clf.fit(X_train,y_train)
	# score = cross_val_score(clf, X, y, cv=cv).mean()
    clf.predict(X_test)
    plot_roc_cv(y_test, a, "test","./")
    # print('训练集准确率：', accuracy_score(y_train, clf.predict(X_train)));
	eva = calculate_metrics(y_test.tolist(), clf.predict(X_test)
	importance = 0;
	if b == 0:
		importance = clf.feature_importances_;
	print(score)
	# h = clf.predict_proba(X)
	return clf.predict(X), importance