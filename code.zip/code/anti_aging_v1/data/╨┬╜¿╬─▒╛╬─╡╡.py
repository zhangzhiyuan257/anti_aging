import pandas as pd
import numpy as np

def fasta_format(path,output):
    data = pd.read_csv(path)
    data_string = ""
    for i in range(len(data[data.columns[0]])):
        data_string += ">"+data[data.columns[0]][i]+"\n"+data[data.columns[1]][i]+"\n"

    with open(output,"w") as file:
        file.write(data_string)
