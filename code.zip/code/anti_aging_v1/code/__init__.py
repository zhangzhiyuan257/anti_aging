#!/usr/bin/env python
#_*_ coding:utf-8 _*_

__all__ = ['readFasta']
