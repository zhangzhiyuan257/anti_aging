import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from code  import readFasta
from feature_extraction  import *
from other_script import *
import random
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.feature_selection import RFE
from sklearn.feature_selection import RFECV
from sklearn.metrics import accuracy_score, classification_report,roc_curve,auc
import joblib

def main():
### 1.read data
    positive_data = readFasta.readFasta("./data/positive_0.9.fasta");
    random.shuffle(positive_data)
    # print(positive_data[215:220])
    negative_data_1 = readFasta.readFasta("./data/nega_toxin_0.9.fasta");
   # print(positive_data[1:5])
    negative_data_2 = readFasta.readFasta("./data/output_infla_0.9.fasta")[:17];
    negative_data= negative_data_1+negative_data_2
    random.shuffle(negative_data)
    # print(len(negative_data))

    # all_data = negative_data[:200] + positive_data[:200]
    all_data = positive_data[:200]
    independent_data = negative_data[200:] + positive_data[200:]
    # print(all_data[439])
### 2.提取特征
    ### 2.1 序列特征
    ### 训练集+测试集
    name = []
    DDE_fea = DDE.DDE(all_data)
    name.append(len(DDE_fea[0]))
    DDE_pd = pd.DataFrame(DDE_fea, columns=DDE_fea[0])

    # CKSAAP_2_pd = pd.DataFrame(CKSAAP_2_pd, columns=CKSAAP_2_pd[0])
    # CTriad_4_pd = pd.DataFrame(CTriad_4_pd, columns=CTriad_4_pd[0])
    # DDE_pd = pd.DataFrame(DDE_pd, columns=DDE_pd[0])
    # aac_tpc = pd.DataFrame(aac_tpc, columns=aac_tpc[0])
    ### 独立验证集

    DDE_fea_indepedent = DDE.DDE(independent_data)

    DDE_pd_in = pd.DataFrame(DDE_fea_indepedent, columns=DDE_fea_indepedent[0])

    X = DDE_pd.iloc[1:, 2:]
    # print(new_feature)
# # # 训练学习模型
#     DDE_pd = machine_learning.LR_demo_2(DDE_pd,DDE_pd_in,"DDE")
    clf = joblib.load("./other_script/DDE.pkl")
    x_predict = list(clf.predict_proba(X))
    x_predict = [list(i) for i in x_predict]
    print(x_predict);

if __name__=="__main__":
    main()
