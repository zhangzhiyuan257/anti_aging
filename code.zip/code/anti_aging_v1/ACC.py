import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from code  import readFasta
from feature_extraction  import *
from other_script import *
import random
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.feature_selection import RFE
from sklearn.feature_selection import RFECV
from sklearn.metrics import accuracy_score, classification_report,roc_curve,auc

def main():
### 1.read data
    positive_data = readFasta.readFasta("./data/positive_0.9.fasta");
    random.shuffle(positive_data)
    # print(positive_data[215:220])
    negative_data_1 = readFasta.readFasta("./data/nega_toxin_0.9.fasta");
   # print(positive_data[1:5])
    negative_data_2 = readFasta.readFasta("./data/output_infla_0.9.fasta")[:17];
    negative_data= negative_data_1+negative_data_2
    random.shuffle(negative_data)
    # print(len(negative_data))

    all_data = negative_data[:200] + positive_data[:200]
    independent_data = negative_data[200:] + positive_data[200:]
    # print(all_data[439])
### 2.提取特征
    ### 2.1 序列特征
    ### 训练集+测试集

    AAC_fea = AAC.AAC(all_data)

    AAC_pd = pd.DataFrame(AAC_fea, columns=AAC_fea[0])

    # print(new_feature)
# # # 训练学习模型
    AAC_pd  = machine_learning.ml(AAC_pd, "AAC_pd")
if __name__=="__main__":
    main()
